from .qcloudapi import Api
from .params import Parameter

if __name__ == '__main__':
    print("All is Ok")
